package za.co.idt.steelstock

import android.os.Bundle
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Black = Color(0xFF050505)
private val Panel = Color(0xFF101315)
private val Panel2 = Color(0xFF171B1D)
private val Green = Color(0xFF39FF14)
private val Orange = Color(0xFFFF7900)
private val White = Color(0xFFF3F3F3)
private val Grey = Color(0xFF9AA0A3)

private data class SteelItem(
    val id: String,
    val type: String,
    val material: String,
    val profile: String,
    val size: String,
    val lengthM: Double,
    val quantity: Int,
    val location: String,
    val status: String
)

private val demoItems = listOf(
    SteelItem("ST-0001", "Full-Length", "Mild Steel", "Square Tube", "50 x 50 x 2 mm", 6.0, 12, "Workshop", "Available"),
    SteelItem("ST-0002", "Full-Length", "Mild Steel", "Rectangular Tube", "100 x 50 x 2 mm", 6.0, 8, "Workshop", "Available"),
    SteelItem("ST-0003", "Full-Length", "Mild Steel", "Angle Iron", "50 x 50 x 5 mm", 6.0, 15, "Site 1", "Available"),
    SteelItem("ST-0004", "Full-Length", "Mild Steel", "Flat Bar", "30 x 5 mm", 6.0, 20, "Workshop", "Available"),
    SteelItem("OC-0001", "Off-Cut", "Mild Steel", "Square Tube", "50 x 50 x 2 mm", 1.8, 1, "Workshop", "Available"),
    SteelItem("OC-0002", "Off-Cut", "Mild Steel", "Rectangular Tube", "100 x 50 x 2 mm", 2.4, 3, "Workshop", "Available"),
    SteelItem("OC-0003", "Off-Cut", "Mild Steel", "Round Tube", "38 mm", 1.2, 5, "Site 1", "Available"),
    SteelItem("OC-0004", "Off-Cut", "Mild Steel", "Flat Bar", "25 x 5 mm", 0.8, 6, "Workshop", "Available")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { IDTSteelStockApp() }
    }
}

@Composable
fun IDTSteelStockApp() {
    var selected by remember { mutableStateOf("Home") }
    var items by remember { mutableStateOf(demoItems) }
    var editing by remember { mutableStateOf<SteelItem?>(null) }
    var showAdd by remember { mutableStateOf<String?>(null) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green,
            secondary = Orange,
            background = Black,
            surface = Panel,
            onPrimary = Color.Black,
            onBackground = White,
            onSurface = White
        )
    ) {
        Box(Modifier.fillMaxSize().background(Black)) {
            when {
                showAdd != null -> StockForm(
                    type = showAdd!!,
                    onBack = { showAdd = null },
                    onSave = { newItem ->
                        items = items + newItem
                        showAdd = null
                    }
                )
                editing != null -> StockForm(
                    type = editing!!.type,
                    existing = editing,
                    onBack = { editing = null },
                    onSave = { updated ->
                        items = items.map { if (it.id == updated.id) updated else it }
                        editing = null
                    }
                )
                else -> MainScaffold(
                    selected = selected,
                    onSelected = { selected = it },
                    items = items,
                    onAdd = { showAdd = it },
                    onEdit = { editing = it }
                )
            }
        }
    }
}

@Composable
private fun MainScaffold(
    selected: String,
    onSelected: (String) -> Unit,
    items: List<SteelItem>,
    onAdd: (String) -> Unit,
    onEdit: (SteelItem) -> Unit
) {
    Scaffold(
        containerColor = Black,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0A0C0D), tonalElevation = 0.dp) {
                listOf("Home", "Full Stock", "Off-Cuts", "Search", "Reports").forEach { label ->
                    val icon = when (label) {
                        "Home" -> Icons.Default.Home
                        "Full Stock" -> Icons.Default.Inventory2
                        "Off-Cuts" -> Icons.Default.Build
                        "Search" -> Icons.Default.Search
                        else -> Icons.Default.Description
                    }
                    NavigationBarItem(
                        selected = selected == label,
                        onClick = { onSelected(label) },
                        icon = { Icon(icon, null) },
                        label = { Text(label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Orange,
                            selectedTextColor = Orange,
                            unselectedIconColor = Grey,
                            unselectedTextColor = Grey,
                            indicatorColor = Color.Transparent
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (selected) {
                "Home" -> HomeScreen(items, onSelected, onAdd)
                "Sync" -> SyncScreen()
                "Full Stock" -> StockListScreen("Full-Length Stock", items.filter { it.type == "Full-Length" }, onAdd, onEdit)
                "Off-Cuts" -> StockListScreen("Off-Cut Stock", items.filter { it.type == "Off-Cut" }, onAdd, onEdit)
                "Search" -> SearchScreen(items, onEdit)
                "Reports" -> ReportsScreen(items)
            }
        }
    }
}

@Composable
private fun AppTitle() {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Text("I.D.T.", color = Green, fontSize = 42.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        Text("STEELWORKS AND ENGINEERING", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Text("STEEL STOCK INVENTORY", color = Orange, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
    }
}

@Composable
private fun HomeScreen(items: List<SteelItem>, onSelected: (String) -> Unit, onAdd: (String) -> Unit) {
    val full = items.filter { it.type == "Full-Length" }
    val off = items.filter { it.type == "Off-Cut" }
    val totalFull = full.sumOf { it.lengthM * it.quantity }
    val totalOff = off.sumOf { it.lengthM * it.quantity }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Spacer(Modifier.height(8.dp))
        AppTitle()
        Spacer(Modifier.height(16.dp))
        SteelBanner()
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SteelDashboardTile("Full-Length\nStock", Modifier.weight(1f)) { onSelected("Full Stock") }
            DashboardTile("Off-Cut\nStock", Icons.Default.Build, Modifier.weight(1f)) { onSelected("Off-Cuts") }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DashboardTile("Stock\nSearch", Icons.Default.Search, Modifier.weight(1f)) { onSelected("Search") }
            DashboardTile("Reports", Icons.Default.Description, Modifier.weight(1f)) { onSelected("Reports") }
        }
        Spacer(Modifier.height(16.dp))
        SummaryCard("CURRENT STOCK", "Full-length: ${full.sumOf { it.quantity }} pieces • ${"%.1f".format(totalFull)} m", "Off-cuts: ${off.sumOf { it.quantity }} pieces • ${"%.1f".format(totalOff)} m")
        Spacer(Modifier.height(12.dp))
        SyncCard(onClick = { onSelected("Sync") })
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun SteelBanner() {
    Box(
        Modifier.fillMaxWidth().height(105.dp).clip(RoundedCornerShape(14.dp)).background(
            Brush.linearGradient(listOf(Color(0xFF34383A), Color(0xFF101214), Color(0xFF4A4D4F)))
        ).border(1.dp, Color(0xFF3B4144), RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf("▣", "▭", "○", "▱", "◫").forEach { Text(it, color = Color.LightGray, fontSize = 35.sp, fontWeight = FontWeight.Bold) }
        }
    }
}


@Composable
private fun SteelDashboardTile(title: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.fillMaxWidth().height(115.dp).clip(RoundedCornerShape(12.dp)).border(1.dp, Green, RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        androidx.compose.foundation.Image(
            painter = painterResource(id = za.co.idt.steelstock.R.drawable.ic_steel_stock),
            contentDescription = null,
            modifier = Modifier.size(42.dp),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.height(6.dp))
        Text(title, color = Green, fontWeight = FontWeight.Bold, fontSize = 15.sp, textAlign = TextAlign.Center)
    }
}
@Composable
private fun DashboardTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.fillMaxWidth().height(115.dp).clip(RoundedCornerShape(12.dp)).border(1.dp, Green, RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = Green, modifier = Modifier.size(36.dp))
        Spacer(Modifier.height(8.dp))
        Text(title, color = Green, fontWeight = FontWeight.Bold, fontSize = 15.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun SummaryCard(title: String, line1: String, line2: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Text(line1, color = White)
            Text(line2, color = White)
        }
    }
}

@Composable
private fun SyncCard(onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Cloud, null, tint = Green, modifier = Modifier.size(42.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Sync Status", color = White, fontWeight = FontWeight.Bold)
                Text("Synced", color = Green, fontWeight = FontWeight.Bold)
                Text("Shared inventory • ready for workshop/site devices", color = Grey, fontSize = 11.sp)
            }
            Icon(Icons.Default.Sync, null, tint = Green)
        }
    }
}

@Composable
private fun StockListScreen(title: String, list: List<SteelItem>, onAdd: (String) -> Unit, onEdit: (SteelItem) -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = list.filter { it.size.contains(query, true) || it.profile.contains(query, true) || it.id.contains(query, true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Header(title)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            FilterBox("All Material", Modifier.weight(1f))
            FilterBox("All Location", Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search size...", color = Grey) }, leadingIcon = { Icon(Icons.Default.Search, null) }, colors = fieldColors())
        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
            items(filtered) { item -> StockRow(item, onEdit) }
        }
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomEnd) {
            FloatingActionButton(onClick = { onAdd(if (title.contains("Off")) "Off-Cut" else "Full-Length") }, containerColor = Orange, contentColor = Color.Black) { Icon(Icons.Default.Add, null) }
        }
    }
}

@Composable
private fun Header(title: String) {
    Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.ArrowBack, null, tint = Green)
        Spacer(Modifier.width(12.dp))
        Text(title, color = Green, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Icon(Icons.Default.Search, null, tint = Green)
    }
}

@Composable
private fun FilterBox(text: String, modifier: Modifier) {
    Box(modifier.height(50.dp).clip(RoundedCornerShape(8.dp)).background(Panel2).border(1.dp, Color(0xFF303638), RoundedCornerShape(8.dp)).padding(horizontal = 12.dp), contentAlignment = Alignment.CenterStart) {
        Text(text, color = White, fontSize = 13.sp)
    }
}

@Composable
private fun StockRow(item: SteelItem, onEdit: (SteelItem) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Panel).clickable { onEdit(item) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(58.dp).clip(RoundedCornerShape(8.dp)).background(Brush.linearGradient(listOf(Color(0xFF6B6E70), Color(0xFF222527)))), contentAlignment = Alignment.Center) {
            Text(if (item.profile.contains("Round")) "○" else "▣", color = Color.LightGray, fontSize = 28.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(item.id, color = Green, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(item.profile, color = White, fontWeight = FontWeight.SemiBold)
            Text(item.size, color = White, fontSize = 12.sp)
            Text("Length: ${item.lengthM} m   Qty: ${item.quantity}", color = White, fontSize = 12.sp)
            Text("Location: ${item.location}", color = Grey, fontSize = 11.sp)
            Spacer(Modifier.height(2.dp))
            StatusPill(item.status)
        }
        Text("›", color = Grey, fontSize = 28.sp)
    }
}

@Composable
private fun StatusPill(status: String) {
    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xFF1B4D12)).padding(horizontal = 9.dp, vertical = 3.dp)) {
        Text(status, color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SearchScreen(items: List<SteelItem>, onEdit: (SteelItem) -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = items.filter { query.isBlank() || listOf(it.id, it.material, it.profile, it.size, it.location).any { v -> v.contains(query, true) } }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Header("Search Stock")
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search steel, size, ID or location...", color = Grey) }, leadingIcon = { Icon(Icons.Default.Search, null) }, colors = fieldColors())
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) { items(filtered) { StockRow(it, onEdit) } }
    }
}

@Composable
private fun ReportsScreen(items: List<SteelItem>) {
    val context = LocalContext.current
    var generating by remember { mutableStateOf(false) }
    var lastReport by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Header("Reports")
        Text("Generate and share stock reports", color = Grey, fontSize = 12.sp, modifier = Modifier.padding(bottom = 10.dp))
        ReportRow("Full-Length Stock Report", "All full-length stock", Icons.Default.Inventory2) {
            generating = true
            lastReport = generateStockPdf(context, "Full-Length Stock Report", items.filter { it.type == "Full-Length" })
            generating = false
        }
        ReportRow("Off-Cut Stock Report", "All off-cut stock", Icons.Default.Build) {
            generating = true
            lastReport = generateStockPdf(context, "Off-Cut Stock Report", items.filter { it.type == "Off-Cut" })
            generating = false
        }
        ReportRow("Combined Stock Report", "Full-length and off-cuts", Icons.Default.Description) {
            generating = true
            lastReport = generateStockPdf(context, "Combined Stock Report", items)
            generating = false
        }
        ReportRow("Stock by Location", "Grouped by location", Icons.Default.LocationOn) {
            generating = true
            lastReport = generateGroupedPdf(context, "Stock by Location", items, true)
            generating = false
        }
        ReportRow("Stock by Material", "Grouped by material", Icons.Default.Inventory2) {
            generating = true
            lastReport = generateGroupedPdf(context, "Stock by Material", items, false)
            generating = false
        }
        ReportRow("Stock Summary", "Total quantities and metres", Icons.Default.Description) {
            generating = true
            lastReport = generateSummaryPdf(context, items)
            generating = false
        }

        Spacer(Modifier.height(12.dp))
        SummaryCard("REPORT DATA", "${items.size} stock records", "${items.sumOf { it.quantity }} total pieces • ${"%.1f".format(items.sumOf { it.lengthM * it.quantity })} total metres")

        if (generating) {
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(color = Green, modifier = Modifier.fillMaxWidth())
        }

        lastReport?.let { path ->
            Spacer(Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PictureAsPdf, null, tint = Green, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("PDF ready", color = Green, fontWeight = FontWeight.Bold)
                        Text(path.substringAfterLast('/'), color = Grey, fontSize = 10.sp)
                    }
                    IconButton(onClick = { openPdf(context, File(path)) }) {
                        Icon(Icons.Default.Description, "Open PDF", tint = Green)
                    }
                    IconButton(onClick = { sharePdf(context, File(path)) }) {
                        Icon(Icons.Default.Share, "Share PDF", tint = Orange)
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(10.dp)).background(Panel).clickable(onClick = onClick).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Green, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text(title, color = White, fontWeight = FontWeight.Bold); Text(subtitle, color = Grey, fontSize = 11.sp) }
        Text("›", color = Green, fontSize = 26.sp)
    }
}

private fun generateStockPdf(context: android.content.Context, title: String, items: List<SteelItem>): String {
    val document = PdfDocument()
    val pageWidth = 595
    val pageHeight = 842
    val margin = 28f
    val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(35, 150, 35); textSize = 20f; typeface = Typeface.DEFAULT_BOLD }
    val orangePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(255, 121, 0); textSize = 12f; typeface = Typeface.DEFAULT_BOLD }
    val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.DKGRAY; textSize = 9f }
    val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.GRAY; textSize = 8f }
    val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.LTGRAY; strokeWidth = 1f }
    var pageNo = 1
    var page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNo).create())
    var canvas = page.canvas
    fun header() {
        canvas.drawText("I.D.T.", margin, 42f, titlePaint)
        canvas.drawText("STEELWORKS AND ENGINEERING", margin, 57f, smallPaint)
        canvas.drawText(title, margin, 84f, orangePaint)
        canvas.drawText("Generated: ${SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date())}", margin, 99f, smallPaint)
        canvas.drawLine(margin, 110f, pageWidth - margin, 110f, linePaint)
    }
    header()
    var y = 130f
    val headers = listOf("ID", "Profile", "Size", "Len m", "Qty", "Location", "Status")
    val xs = floatArrayOf(margin, 82f, 190f, 325f, 380f, 425f, 505f)
    headers.forEachIndexed { i, h -> canvas.drawText(h, xs[i], y, orangePaint) }
    y += 14f
    items.forEach { item ->
        if (y > pageHeight - 35f) {
            document.finishPage(page)
            pageNo++
            page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNo).create())
            canvas = page.canvas
            header(); y = 130f
        }
        canvas.drawText(item.id.take(12), xs[0], y, textPaint)
        canvas.drawText(item.profile.take(17), xs[1], y, textPaint)
        canvas.drawText(item.size.take(20), xs[2], y, textPaint)
        canvas.drawText("%.1f".format(item.lengthM), xs[3], y, textPaint)
        canvas.drawText(item.quantity.toString(), xs[4], y, textPaint)
        canvas.drawText(item.location.take(12), xs[5], y, textPaint)
        canvas.drawText(item.status.take(10), xs[6], y, textPaint)
        canvas.drawLine(margin, y + 5f, pageWidth - margin, y + 5f, linePaint)
        y += 18f
    }
    canvas.drawText("Total pieces: ${items.sumOf { it.quantity }}", margin, pageHeight - 22f, smallPaint)
    canvas.drawText("Total metres: %.1f".format(items.sumOf { it.lengthM * it.quantity }), 180f, pageHeight - 22f, smallPaint)
    document.finishPage(page)
    return savePdf(context, document, title)
}

private fun generateGroupedPdf(context: android.content.Context, title: String, items: List<SteelItem>, byLocation: Boolean): String {
    val groups = if (byLocation) items.groupBy { it.location } else items.groupBy { it.material }
    val summaryItems = groups.entries.sortedBy { it.key }.map { entry ->
        SteelItem(entry.key, "Group", if (byLocation) "All Materials" else entry.key, "", "", entry.value.sumOf { it.lengthM * it.quantity }, entry.value.sumOf { it.quantity }, if (byLocation) entry.key else "All Locations", "Available")
    }
    return generateStockPdf(context, title, summaryItems)
}

private fun generateSummaryPdf(context: android.content.Context, items: List<SteelItem>): String {
    return generateStockPdf(context, "Stock Summary", items)
}

private fun savePdf(context: android.content.Context, document: PdfDocument, title: String): String {
    val dir = File(context.cacheDir, "reports").apply { mkdirs() }
    val safe = title.replace(Regex("[^A-Za-z0-9]+"), "_")
    val file = File(dir, "${safe}_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.pdf")
    file.outputStream().use { document.writeTo(it) }
    document.close()
    Toast.makeText(context, "PDF report created", Toast.LENGTH_SHORT).show()
    return file.absolutePath
}

private fun openPdf(context: android.content.Context, file: File) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "application/pdf")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try { context.startActivity(intent) } catch (_: Exception) { Toast.makeText(context, "No PDF viewer installed", Toast.LENGTH_LONG).show() }
}

private fun sharePdf(context: android.content.Context, file: File) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Share stock report"))
}

@Composable
private fun SyncScreen() {
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Header("Sync & Settings")
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Cloud, null, tint = Green, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Sync Status", color = Green, fontWeight = FontWeight.Bold)
                        Text("Synced", color = Green, fontWeight = FontWeight.Bold)
                        Text("Shared inventory database", color = Grey, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Button(onClick = {}, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)) {
                    Icon(Icons.Default.Sync, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Sync Now", fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        SettingsRow("This Device", "Workshop / Site device name", Icons.Default.Settings)
        SettingsRow("Locations", "Manage Workshop, Site 1, Site 2", Icons.Default.LocationOn)
        SettingsRow("Materials", "Manage material list", Icons.Default.Inventory2)
        SettingsRow("Profiles", "Manage steel profiles", Icons.Default.Build)
        SettingsRow("Sizes", "Manage common sizes", Icons.Default.Straighten)
        Spacer(Modifier.height(12.dp))
        Text("SYNC ARCHITECTURE", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text("Each device keeps its local stock available offline. When internet is available, changes are synchronised with the shared cloud database so workshop and site devices use the same inventory.", color = Grey, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
private fun SettingsRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(10.dp)).background(Panel).clickable {}.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Green, modifier = Modifier.size(27.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = White, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Grey, fontSize = 11.sp)
        }
        Text("›", color = Grey, fontSize = 26.sp)
    }
}

@Composable
private fun StockForm(type: String, existing: SteelItem? = null, onBack: () -> Unit, onSave: (SteelItem) -> Unit) {
    var id by remember { mutableStateOf(existing?.id ?: if (type == "Off-Cut") "OC-0005" else "ST-0005") }
    var material by remember { mutableStateOf(existing?.material ?: "Mild Steel") }
    var profile by remember { mutableStateOf(existing?.profile ?: "Square Tube") }
    var size by remember { mutableStateOf(existing?.size ?: "50 x 50 x 2 mm") }
    var length by remember { mutableStateOf(existing?.lengthM?.toString() ?: "6.0") }
    var quantity by remember { mutableStateOf(existing?.quantity?.toString() ?: "1") }
    var location by remember { mutableStateOf(existing?.location ?: "Workshop") }
    var status by remember { mutableStateOf(existing?.status ?: "Available") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ArrowBack, null, tint = Green, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(12.dp))
            Text(if (existing == null) "Add $type Stock" else "Edit Stock", color = Green, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(14.dp))
        FormField("Stock ID", id) { id = it }
        FormField("Material", material) { material = it }
        FormField("Profile", profile) { profile = it }
        FormField("Size", size) { size = it }
        FormField("Length (m)", length) { length = it }
        FormField("Quantity", quantity) { quantity = it }
        FormField("Location", location) { location = it }
        FormField("Status", status) { status = it }
        Spacer(Modifier.height(10.dp))
        Button(onClick = {
            onSave(SteelItem(id, type, material, profile, size, length.toDoubleOrNull() ?: 0.0, quantity.toIntOrNull() ?: 0, location, status))
        }, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black), shape = RoundedCornerShape(10.dp)) {
            Text(if (existing == null) "Save Stock" else "Update Stock", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun FormField(label: String, value: String, onChange: (String) -> Unit) {
    Text(label, color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    OutlinedTextField(value, onChange, modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 9.dp), singleLine = true, colors = fieldColors())
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Green,
    unfocusedBorderColor = Color(0xFF303638),
    focusedTextColor = White,
    unfocusedTextColor = White,
    cursorColor = Green,
    focusedLabelColor = Green,
    unfocusedLabelColor = Grey
)
