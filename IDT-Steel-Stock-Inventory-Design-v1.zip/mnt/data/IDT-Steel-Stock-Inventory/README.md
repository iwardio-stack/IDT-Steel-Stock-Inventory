# I.D.T. Steel Stock Inventory

Android app project based on the approved I.D.T. Steel Stock Inventory mockup.

## Master design
- Black / dark industrial interface
- Neon green branding and headings
- Orange action buttons
- Dashboard with Full-Length Stock, Off-Cut Stock, Search and Reports
- Full-length and off-cut lists
- Add/Edit stock forms
- Stock details/search/report concepts
- Sync & Settings screen

## Stock fields
- Stock ID
- Material
- Profile
- Size
- Length (m)
- Quantity
- Location
- Status

Removed from the design: purchase date, supplier, notes, photos, cutting workflows, issuing to site, returning steel, and scrapping.

## Multi-device sync
The project includes Firebase Firestore as the planned cloud sync layer. To activate real synchronization:
1. Create a Firebase project.
2. Enable Cloud Firestore.
3. Register Android app package `za.co.idt.steelstock`.
4. Download `google-services.json` into `app/`.
5. Add the Google Services Gradle plugin to the root/app build configuration.
6. Replace the demo/local repository with the Firestore repository and add device/user identification.

The UI and data model are intentionally separated so the sync layer can be connected without changing the approved screens.

## Build
Open the project in Android Studio and let Android Studio install/sync the Gradle components. The project targets Java/Kotlin 17 and Android API 35.
